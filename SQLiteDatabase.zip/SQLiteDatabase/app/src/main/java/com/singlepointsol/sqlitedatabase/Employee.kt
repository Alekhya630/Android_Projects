package com.singlepointsol.sqlitedatabase

data class Employee(val name:String, val email:String, val phone: String)
