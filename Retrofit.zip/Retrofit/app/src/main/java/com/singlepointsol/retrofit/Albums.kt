package com.singlepointsol.retrofit

class Albums:ArrayList<AlbumItem>() {
}