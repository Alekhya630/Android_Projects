package com.singlepointsol.employeesrealtimedb

data class Employee(val name:String?=null, val email:String?=null, val phone: String?=null, val designation: String?=null)

