package com.singlepointsol.nykaaproductdetails

data class NykaaProduct(val productname: String?=null, val productprice: String?=null, val productmanufacture: String?=null, val country: String?=null)
