package com.singlepointsol.sqlitedatabaseassignment

data class Employee(val name:String, val email:String, val password: String){

}
