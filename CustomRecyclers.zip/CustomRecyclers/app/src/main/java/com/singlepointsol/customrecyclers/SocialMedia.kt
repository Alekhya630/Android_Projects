package com.singlepointsol.customrecyclers

data class SocialMedia(val  socialImage: Int, val socialName: String)
